let left = document.getElementById('left')
let right = document.getElementById('right')

let slides = document.querySelectorAll('.img')

let index = 0

function showSlide(i){
    slides.forEach(s => s.classList.remove("active"))
    slides[i].classList.add('active')

}

right.addEventListener('click', () =>{
    index = (index + 1) % slides.length
    showSlide(index)
})

left.addEventListener('click', ()=>{
    index = (index - 1 + slides.length) % slides.length
    showSlide(index)
})